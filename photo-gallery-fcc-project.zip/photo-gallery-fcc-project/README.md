# Photo Gallery FCC Project

A Pen created on CodePen.io. Original URL: [https://codepen.io/rebeccapackarddesigns/pen/JjpgpGv](https://codepen.io/rebeccapackarddesigns/pen/JjpgpGv).

